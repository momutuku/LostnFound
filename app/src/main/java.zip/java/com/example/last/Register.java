package com.example.last;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
  //Variables
  Button register, loginbk;
  TextInputEditText fname, lname, phone, cfmpass, email, pasd;

  private static final String TAG = "MainActivity";
  private FirebaseAuth mAuth;
  FirebaseDatabase databaser;


  @Override
  protected void onCreate(Bundle savedInstanceState) {

    super.onCreate(savedInstanceState);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    setContentView(R.layout.activity_register);
    mAuth = FirebaseAuth.getInstance();

    if (globalconst.user != null) {
      Intent intent = new Intent(Register.this, Dashboard.class);
      startActivity(intent);
      finish();

    }

    email = findViewById(R.id.regem);
    fname = findViewById(R.id.fname1);
    lname = findViewById(R.id.lname1);
    phone = findViewById(R.id.tell1);
    pasd = findViewById(R.id.regpp);
    cfmpass = findViewById(R.id.regconf);
    register = findViewById(R.id.registerbtn);
    loginbk = findViewById(R.id.bklogin);


    loginbk.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        Intent intent = new Intent(Register.this, Login.class);
        startActivity(intent);
        Toast.makeText(Register.this, "Clicked",
                Toast.LENGTH_SHORT).show();


      }
    });


  }

  private Boolean validateEmail() {
    String mail = email.getText().toString();
    String mailPattern = "[a-zA-z0-9._-]+@[a-z]+\\.+[a-z]+";
    if (mail.isEmpty()) {
      email.setError("Field is required");
      return false;
    } else if (!mail.matches(mailPattern)) {
      email.setError("Invalid Email");
      return false;
    } else {
      email.setError(null);
      return true;
    }
  }

  private Boolean validatePassword() {
    String passw = pasd.getText().toString();
    String cpassw = cfmpass.getText().toString();
    pasd.setError(null);
    cfmpass.setError(null);
    if (passw == cpassw) {

      if (passw.isEmpty() && cpassw.isEmpty()) {

        pasd.setError("Field is required");
        cfmpass.setError("Field is required");
        return false;
      } else if (passw.isEmpty()) {
        pasd.setError("Field is required");
        return false;
      } else if (cpassw.isEmpty()) {
        cfmpass.setError("Field is required");
        return false;
      } else
        pasd.setError(null);
      cfmpass.setError(null);
      return true;
    } else {
      return false;
    }
  }


  public void registerUser(View view) {

    final String eemail = email.getText().toString();
    String pasw = pasd.getText().toString();


    mAuth.createUserWithEmailAndPassword(eemail, pasw).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
      @Override
      public void onComplete(@NonNull Task<AuthResult> task) {
        if (task.isSuccessful()) {
          // Sign in success, update UI with the signed-in user's information
          Toast.makeText(Register.this, "Created",
                  Toast.LENGTH_SHORT).show();
          String UID = mAuth.getCurrentUser().getUid();
          DatabaseReference userdb = databaser.getInstance().getReference().child("Users").child(UID);
          String name = fname.getText().toString();
          String ltname = lname.getText().toString();
          String telno = phone.getText().toString();

          Map saver = new HashMap();
          saver.put("Email", eemail);
          saver.put("FirstName", name);
          saver.put("LastName", ltname);
          saver.put("PhoneNumber", telno);

          userdb.setValue(saver);
          globalconst.user = mAuth.getCurrentUser();

//                    Move to next Activity
          Intent intent = new Intent(Register.this, Dashboard.class);
//                    intent.putExtra("email", eemail);
          globalconst.gmail = eemail;
//                    intent.putExtra("Name", name);
          globalconst.gname = name;
//                    intent.putExtra("lName", ltname);
          globalconst.gltname = ltname;
//                    intent.putExtra("Phone", telno);
          globalconst.gtelno = telno;
          startActivity(intent);
          finish();
          //updateUI(user);
        } else {
          // If sign in fails, display a message to the user.
          Log.w(TAG, "createUserWithEmail:failure", task.getException());
          Toast.makeText(Register.this, "Authentication failed.",
                  Toast.LENGTH_SHORT).show();
          //updateUI(null);
        }
      }
    });


  }


}
