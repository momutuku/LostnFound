package com.example.last;

import android.content.SharedPreferences;
import android.net.Uri;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.net.URI;

import static android.content.Context.MODE_PRIVATE;

public class globalconst {
    public static FirebaseUser user;
    public static String gname;
    public static String gmail;
    public static String gltname;
    public static String gtelno;
    public static String gimg = "";

}
