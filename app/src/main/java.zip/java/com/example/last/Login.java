package com.example.last;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Pair;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity {
    //Variables
    Animation topanim, bottomanim;
    ImageView logo;
    TextView slogan;
    private FirebaseAuth mAuth;
    DatabaseReference dbRef;
    FirebaseDatabase baser;
    TextInputEditText email1, pasd1;
    Button loginbtn, forget, signupbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login);


        SharedPreferences preferences = getSharedPreferences("info", MODE_PRIVATE);
        String using = preferences.getString("remember", "");
        if (using.equals("true")){
            Intent dash = new Intent(Login.this,Dashboard.class);
            startActivity(dash);
            finish();
        }



        loginbtn = findViewById(R.id.loginbtn);
        forget = findViewById(R.id.forgotbtn);
        signupbtn = findViewById(R.id.signupbtn);
        logo = findViewById(R.id.logo1);
        slogan = findViewById(R.id.slogan1);
        mAuth = FirebaseAuth.getInstance();

        email1 = findViewById(R.id.email_login);
        pasd1 = findViewById(R.id.password_login);


        topanim = AnimationUtils.loadAnimation(this, R.anim.transition);
        bottomanim = AnimationUtils.loadAnimation(this, R.anim.bottom);

        logo.setAnimation(topanim);
        slogan.setAnimation(bottomanim);

        signupbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, Register.class);
                Pair[] pairs = new Pair[2];
                pairs[0] = new Pair<View, String>(logo, "logo_image");
                pairs[1] = new Pair<View, String>(slogan, "logo_text");

                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    ActivityOptions options = ActivityOptions.makeSceneTransitionAnimation(Login.this, pairs);
                    startActivity(intent, options.toBundle());
                    finish();

                }
            }
        });


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = email1.getText().toString();
                String passwd = pasd1.getText().toString();

                mAuth.signInWithEmailAndPassword(email, passwd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            dbRef = baser.getInstance().getReference().child("Users").child(mAuth.getCurrentUser().getUid());


                            dbRef.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    final String lnamer, fnamer, femail;
                                    final String phonenol;
                                    femail = dataSnapshot.child("Email").getValue(String.class);
                                    fnamer = dataSnapshot.child("FirstName").getValue(String.class);
                                    lnamer = dataSnapshot.child("LastName").getValue(String.class);
                                    phonenol = dataSnapshot.child("PhoneNumber").getValue(String.class);

                                    SharedPreferences preferences = getSharedPreferences("info", MODE_PRIVATE);
                                    SharedPreferences.Editor editor = preferences.edit();
                                    editor.putString("remember", "true");
                                    editor.putString("UID", mAuth.getCurrentUser().getUid());
                                    globalconst.user = mAuth.getCurrentUser();
                                    editor.putString("lname", lnamer);
                                    editor.putString("fname", fnamer);
                                    editor.putString("email", femail);
                                    editor.putString("phnoe", phonenol);
                                    editor.putString("image", "");
                                    editor.commit();
                                    Intent intent = new Intent(Login.this, Dashboard.class);
                                    startActivity(intent);
                                    finish();

                                }


                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });

                        }

                    }
                });


            }
        });


    }
}
