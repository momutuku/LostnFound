package com.example.last;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageException;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
//import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Dashboard extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    ImageView ImgUserphoto;
    TextView Emailp, userpr, hname, hphone, hmail;
    Button updater;
    Bitmap bitmapc;

    Uri pickedImg;
    MenuItem login, profile;
    FirebaseStorage storage = FirebaseStorage.getInstance();
    DatabaseReference ref1;
    StorageReference storageRef = storage.getReferenceFromUrl("gs://lostnfound-d25b8.appspot.com");


    DrawerLayout drawer;
    NavigationView navigationView;
    Toolbar toolbar;
    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(com.example.last.R.layout.activity_dashboard);


        //Hooks
        mAuth = FirebaseAuth.getInstance();
        ImgUserphoto = findViewById(com.example.last.R.id.profileimg);
        updater = findViewById(com.example.last.R.id.update);
        userpr = findViewById(com.example.last.R.id.userp);
        Emailp = findViewById(com.example.last.R.id.email1);
        hname = findViewById(com.example.last.R.id.dashname);
        hphone = findViewById(com.example.last.R.id.dashtel);
        hmail = findViewById(com.example.last.R.id.dashemail);


        final SharedPreferences preferences = getSharedPreferences("info", MODE_PRIVATE);
        String userUID = preferences.getString("UID", "");
        String user = preferences.getString("remember", "");
        String lname = preferences.getString("lname", "");
        String email = preferences.getString("email", "");
        String phnoe = preferences.getString("phnoe", "");
        String fname = preferences.getString("fname", "");
        String image = preferences.getString("image", "");


        hname.setText(lname);
        hmail.setText(email);
        hphone.setText(phnoe);
        Emailp.setText(email);
        userpr.setText(fname);

        drawer = findViewById(com.example.last.R.id.drawer_layout);
        navigationView = findViewById(com.example.last.R.id.nav_view);
        toolbar = findViewById(com.example.last.R.id.toolbar);


        setSupportActionBar(toolbar);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar, com.example.last.R.string.navopen, com.example.last.R.string.navclose);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        Menu menu = navigationView.getMenu();


        login = menu.findItem(com.example.last.R.id.drawer_login);
        login.setVisible(false);

        storageRef.child("Profiles/" + userUID + ".jpg").getBytes(Long.MAX_VALUE).addOnSuccessListener(new OnSuccessListener<byte[]>() {
            @Override
            public void onSuccess(byte[] bytes) {
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                ImgUserphoto.setImageBitmap(bmp);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception exception) {
                // Handle any errors
            }
        });


        updater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
//                Toast.makeText(Dashboard.this, "Authentication failed.", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void openGallery() {

        Intent galleryIntent = new Intent();
        galleryIntent.setType("image/*");
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(galleryIntent, 1);


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            UploadTask uploadTask;
            StorageReference riversRef = storageRef.child("Profiles/" + globalconst.user.getUid() + ".jpg");
            InputStream inputStream = this.getContentResolver().openInputStream(data.getData());
            uploadTask = riversRef.putStream(inputStream);
        } catch (java.io.FileNotFoundException err) {
        }
    }


    private void updateUserInfo(final String mail, Uri picked, final FirebaseUser currentUser) {
        StorageReference mstore = FirebaseStorage.getInstance().getReference().child("Profiles");
        final StorageReference imgPath = mstore.child(pickedImg.getLastPathSegment());
        imgPath.putFile(picked).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                imgPath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        UserProfileChangeRequest profileUpdate = new UserProfileChangeRequest.Builder()
                                .setDisplayName("Me")
                                .setPhotoUri(uri)
                                .build();
                        currentUser.updateProfile(profileUpdate).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {

                                if (task.isSuccessful()) {
                                    showMessage("Updated");
                                    // updateUI();
                                }

                            }
                        });
                    }
                });
            }
        });
    }

    private void showMessage(String updated) {

        Toast.makeText(getApplicationContext(), updated, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }


    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case com.example.last.R.id.logout:
                mAuth.signOut();
                globalconst.user = null;
                globalconst.gmail = "";
                globalconst.gltname = "";
                globalconst.gname = "";
                globalconst.gtelno = "";
                globalconst.gimg = "";
                SharedPreferences preferences = getSharedPreferences("info", MODE_PRIVATE);
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("remember", "false");
                editor.apply();
                Intent intent = new Intent(Dashboard.this, Login.class);
                startActivity(intent);
                finish();
                break;
            case R.id.nav_home:
                Intent navhome = new Intent(Dashboard.this, Profile.class);
                startActivity(navhome);
                break;
            //End Switch
        }
        return true;
    }

    //End onCreate
}
